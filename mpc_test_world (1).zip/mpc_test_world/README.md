# Connected MPC Gazebo Classic Test World

This ROS 2 Humble package provides one bright, wood-colored Gazebo Classic 11
course for MPC tracking tests. The geometry is now physically connected:

1. straight lane;
2. smooth 90-degree corner;
3. 1.5 m clear-width narrow corridor;
4. vertical S corridor;
5. connected 270-degree circular arc;
6. eastbound connector with a forward/reverse bay;
7. connected Omni/Mecanum/4WIS lateral and diagonal arena.

The reverse bay is the only intentional out-and-back branch. Every other
section shares an endpoint with the next section, so the robot can start at
(-23, -15) and traverse the course without being respawned.

The floor, internal walls, center island, and outer boundary use bright oak
RGBA materials embedded directly in the SDF. No external texture is required.
Ambient light was raised and shadows were disabled to avoid the previous dark
appearance.

## Build and launch

~~~bash
source /opt/ros/humble/setup.bash

if [ -f /usr/share/gazebo/setup.sh ]; then
    source /usr/share/gazebo/setup.sh
else
    source /usr/share/gazebo-11/setup.sh
fi

cd /colcon_ws
colcon build --packages-select mpc_test_world
source install/setup.bash
ros2 launch mpc_test_world mpc_test_world.launch.py
~~~

Launch the robot separately or include the package launch file in the robot
bringup. The suggested full-course spawn is:

~~~bash
ros2 run gazebo_ros spawn_entity.py \
  -topic robot_description \
  -entity test_robot \
  -x -23.0 -y -15.0 -z 0.10 -Y 0.0
~~~

To test only the holonomic zone, spawn at (5, 5, 0).

## Connected layout

| Order | Test | Approximate region | Guide |
| ---: | --- | --- | --- |
| 1 | Straight | (-23,-15) to (-12,-15) | Yellow |
| 2 | 90-degree corner | center (-12,-12), radius 3 m | Orange |
| 3 | Narrow corridor | x=-9, y=-12..-4 | White |
| 4 | S curve | x about -10.7..-7.3, y=-4..10 | Green |
| 5 | Circular arc | center (-14,10), radius 5 m, 270 degrees | Blue |
| 6 | Connector | (-14,5) to (4.5,5) | Yellow |
| 7 | Forward/reverse bay | branch at (-3,5) | Purple |
| 8 | Omni/4WIS arena | x=4.5..23.5, y=1..15.5 | Cyan/Magenta |

Exact waypoints, headings, section order, and junction coordinates are in
config/test_routes.yaml.

## Dynamic obstacles

1. dynamic_crossing_obstacle crosses the initial straight every 6 seconds.
2. dynamic_corridor_cart shuttles through the narrow corridor every 10 seconds.
3. dynamic_omni_patrol follows a rectangular 20-second patrol in the
   holonomic arena.

All moving obstacles have collision geometry and are visible to ray sensors.
To disable one, remove or comment out its model in
worlds/mpc_motion_test.world.

## Controller notes

- The differential-drive route ends at the Omni/4WIS entrance (4.5,5).
- In the reverse bay, enter with yaw +pi/2, preserve that yaw while reversing
  to the branch, then rotate east before continuing.
- The Omni/4WIS sequence holds yaw at zero. Its vertical legs therefore
  command body-frame vy, while its diagonal legs command both vx and vy.
- Reduce reference speed in the S and circular sections according to the
  available yaw-rate and lateral-acceleration limits.
- test_routes.yaml is a waypoint reference. If Nav2 uses a static map, that
  map must be regenerated for this new 54 m by 38 m layout.

## Regenerating the world

~~~bash
python3 scripts/generate_world.py worlds/mpc_motion_test.world
~~~

The generated SDF targets Gazebo Classic 11 through gazebo_ros, not modern
Gazebo (gz sim).
