#!/usr/bin/env python3
"""Generate a Nav2 map_server PGM/YAML map from the Gazebo SDF collisions."""

import argparse
import math
import pathlib
import xml.etree.ElementTree as ET
from dataclasses import dataclass


DEFAULT_MAP_BOUNDS = (-24.5, 24.5, -17.5, 17.5)


@dataclass(frozen=True)
class Pose2D:
    x: float = 0.0
    y: float = 0.0
    yaw: float = 0.0


@dataclass(frozen=True)
class BoxShape:
    name: str
    pose: Pose2D
    size_x: float
    size_y: float


@dataclass(frozen=True)
class CircleShape:
    name: str
    pose: Pose2D
    radius: float


def parse_pose(text):
    if text is None or not text.strip():
        return Pose2D()
    values = [float(value) for value in text.split()]
    if len(values) != 6:
        raise ValueError(f"Expected a six-value SDF pose, got: {text}")
    return Pose2D(values[0], values[1], values[5])


def compose(parent, child):
    cosine = math.cos(parent.yaw)
    sine = math.sin(parent.yaw)
    return Pose2D(
        parent.x + cosine * child.x - sine * child.y,
        parent.y + sine * child.x + cosine * child.y,
        parent.yaw + child.yaw,
    )


def box_bounds(shape):
    half_x = 0.5 * shape.size_x
    half_y = 0.5 * shape.size_y
    cosine = math.cos(shape.pose.yaw)
    sine = math.sin(shape.pose.yaw)
    corners = []
    for local_x, local_y in (
        (-half_x, -half_y),
        (half_x, -half_y),
        (half_x, half_y),
        (-half_x, half_y),
    ):
        corners.append((
            shape.pose.x + cosine * local_x - sine * local_y,
            shape.pose.y + sine * local_x + cosine * local_y,
        ))
    return (
        min(point[0] for point in corners),
        max(point[0] for point in corners),
        min(point[1] for point in corners),
        max(point[1] for point in corners),
    )


def extract_collision_shapes(world, model_name):
    model = next(
        (
            candidate
            for candidate in world.findall("model")
            if candidate.get("name") == model_name
        ),
        None,
    )
    if model is None:
        raise ValueError(f"Static model '{model_name}' was not found")

    model_pose = parse_pose(model.findtext("pose"))
    ground_shape = None
    collision_shapes = []

    for link in model.findall("link"):
        link_name = link.get("name", "unnamed_link")
        link_pose = compose(model_pose, parse_pose(link.findtext("pose")))

        for collision in link.findall("collision"):
            collision_name = collision.get("name", "unnamed_collision")
            pose = compose(link_pose, parse_pose(collision.findtext("pose")))
            box = collision.find("geometry/box/size")
            cylinder = collision.find("geometry/cylinder")

            if box is not None:
                size = [float(value) for value in box.text.split()]
                if len(size) != 3:
                    raise ValueError(
                        f"Invalid box size for {link_name}/{collision_name}"
                    )
                shape = BoxShape(
                    f"{link_name}/{collision_name}",
                    pose,
                    size[0],
                    size[1],
                )
                if link_name == "ground":
                    ground_shape = shape
                else:
                    collision_shapes.append(shape)
            elif cylinder is not None:
                radius = float(cylinder.findtext("radius"))
                collision_shapes.append(CircleShape(
                    f"{link_name}/{collision_name}", pose, radius
                ))
            else:
                raise ValueError(
                    "Only box and cylinder collisions are supported: "
                    f"{link_name}/{collision_name}"
                )

    if ground_shape is None:
        raise ValueError("The arena ground collision was not found")
    return ground_shape, collision_shapes


def index_bounds(minimum, maximum, origin, resolution, cell_count):
    first = max(0, int(math.floor((minimum - origin) / resolution)))
    last = min(
        cell_count - 1,
        int(math.ceil((maximum - origin) / resolution)) - 1,
    )
    return first, last


def mark_box(
    pixels,
    width,
    height,
    origin_x,
    origin_y,
    resolution,
    shape,
    margin,
):
    expanded = BoxShape(
        shape.name,
        shape.pose,
        shape.size_x + 2.0 * margin,
        shape.size_y + 2.0 * margin,
    )
    minimum_x, maximum_x, minimum_y, maximum_y = box_bounds(expanded)
    first_x, last_x = index_bounds(
        minimum_x, maximum_x, origin_x, resolution, width
    )
    first_y, last_y = index_bounds(
        minimum_y, maximum_y, origin_y, resolution, height
    )
    cosine = math.cos(expanded.pose.yaw)
    sine = math.sin(expanded.pose.yaw)
    half_x = 0.5 * expanded.size_x
    half_y = 0.5 * expanded.size_y

    for cell_y in range(first_y, last_y + 1):
        world_y = origin_y + (cell_y + 0.5) * resolution
        image_row = height - 1 - cell_y
        row_offset = image_row * width
        for cell_x in range(first_x, last_x + 1):
            world_x = origin_x + (cell_x + 0.5) * resolution
            delta_x = world_x - expanded.pose.x
            delta_y = world_y - expanded.pose.y
            local_x = cosine * delta_x + sine * delta_y
            local_y = -sine * delta_x + cosine * delta_y
            if abs(local_x) <= half_x and abs(local_y) <= half_y:
                pixels[row_offset + cell_x] = 0


def mark_circle(
    pixels,
    width,
    height,
    origin_x,
    origin_y,
    resolution,
    shape,
    margin,
):
    radius = shape.radius + margin
    first_x, last_x = index_bounds(
        shape.pose.x - radius,
        shape.pose.x + radius,
        origin_x,
        resolution,
        width,
    )
    first_y, last_y = index_bounds(
        shape.pose.y - radius,
        shape.pose.y + radius,
        origin_y,
        resolution,
        height,
    )
    radius_squared = radius * radius

    for cell_y in range(first_y, last_y + 1):
        world_y = origin_y + (cell_y + 0.5) * resolution
        image_row = height - 1 - cell_y
        row_offset = image_row * width
        for cell_x in range(first_x, last_x + 1):
            world_x = origin_x + (cell_x + 0.5) * resolution
            delta_x = world_x - shape.pose.x
            delta_y = world_y - shape.pose.y
            if delta_x * delta_x + delta_y * delta_y <= radius_squared:
                pixels[row_offset + cell_x] = 0


def generate_map(
    world_path,
    output_directory,
    resolution,
    margin,
    model_name,
    bounds,
):
    sdf = ET.parse(world_path).getroot()
    world = sdf.find("world")
    if world is None:
        raise ValueError("The SDF file does not contain a <world>")

    ground, collision_shapes = extract_collision_shapes(world, model_name)
    if bounds is None:
        minimum_x, maximum_x, minimum_y, maximum_y = box_bounds(ground)
    else:
        minimum_x, maximum_x, minimum_y, maximum_y = bounds
    if minimum_x >= maximum_x or minimum_y >= maximum_y:
        raise ValueError("Map bounds must have positive width and height")
    width = int(round((maximum_x - minimum_x) / resolution))
    height = int(round((maximum_y - minimum_y) / resolution))
    if width <= 0 or height <= 0:
        raise ValueError("Invalid map dimensions")

    pixels = bytearray([255]) * (width * height)
    for shape in collision_shapes:
        if isinstance(shape, BoxShape):
            mark_box(
                pixels,
                width,
                height,
                minimum_x,
                minimum_y,
                resolution,
                shape,
                margin,
            )
        else:
            mark_circle(
                pixels,
                width,
                height,
                minimum_x,
                minimum_y,
                resolution,
                shape,
                margin,
            )

    output_directory.mkdir(parents=True, exist_ok=True)
    stem = world_path.stem
    pgm_path = output_directory / f"{stem}_map.pgm"
    yaml_path = output_directory / f"{stem}_map.yaml"
    header = f"P5\n# Gazebo static collision map\n{width} {height}\n255\n"
    pgm_path.write_bytes(header.encode("ascii") + bytes(pixels))
    yaml_path.write_text(
        "\n".join((
            f"image: {pgm_path.name}",
            "mode: trinary",
            f"resolution: {resolution:.6f}",
            f"origin: [{minimum_x:.6f}, {minimum_y:.6f}, 0.000000]",
            "negate: 0",
            "occupied_thresh: 0.65",
            "free_thresh: 0.196",
            "",
        )),
        encoding="utf-8",
    )

    occupied_cells = sum(value == 0 for value in pixels)
    print(f"PGM: {pgm_path}")
    print(f"YAML: {yaml_path}")
    print(
        f"size={width}x{height}, resolution={resolution:.3f} m, "
        f"origin=({minimum_x:.3f}, {minimum_y:.3f}), "
        f"occupied={occupied_cells}"
    )
    return pgm_path, yaml_path


def main():
    package_root = pathlib.Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "world",
        nargs="?",
        type=pathlib.Path,
        default=package_root / "worlds" / "mpc_motion_test.world",
    )
    parser.add_argument(
        "output_directory",
        nargs="?",
        type=pathlib.Path,
        default=package_root / "map",
    )
    parser.add_argument("--resolution", type=float, default=0.05)
    parser.add_argument("--margin", type=float, default=0.0)
    parser.add_argument("--model", default="mpc_test_arena")
    parser.add_argument(
        "--bounds",
        nargs=4,
        type=float,
        default=DEFAULT_MAP_BOUNDS,
        metavar=("MIN_X", "MAX_X", "MIN_Y", "MAX_Y"),
        help=(
            "map world bounds; defaults to the cropped course extent "
            "-24.5 24.5 -17.5 17.5"
        ),
    )
    arguments = parser.parse_args()
    if arguments.resolution <= 0.0:
        parser.error("--resolution must be positive")
    if arguments.margin < 0.0:
        parser.error("--margin must not be negative")
    generate_map(
        arguments.world.resolve(),
        arguments.output_directory.resolve(),
        arguments.resolution,
        arguments.margin,
        arguments.model,
        tuple(arguments.bounds),
    )


if __name__ == "__main__":
    main()
