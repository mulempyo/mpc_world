# mpc_test_world

ROS 2 Humble + Gazebo Classic용 소형 실내 MPC/로컬 플래너 시험 환경입니다.

## 환경 구성

- 전체 실내 크기: 12 m × 10 m
- 물류 랙 4개와 팔레트 적재물
- 승객 대기 벤치와 픽업 구역
- 서쪽 벽의 녹색 충전 도크
- 충돌체가 포함된 동적 장애물 3개
  - `warehouse_worker`: 중앙 통로를 왕복하는 작업자
  - `passenger_crossing`: 승객 대기 구역을 출입하는 사람
  - `autonomous_cart`: 랙 외곽을 순환하는 운반 카트

동적 장애물은 시각 애니메이션만 움직이는 actor가 아니라 실제 collision을 가진
모델입니다. 따라서 LiDAR 및 obstacle layer에서 검출할 수 있습니다.

## 빌드

```bash
cd /colcon_ws
colcon build --symlink-install --packages-select mpc_test_world
source install/setup.bash
```

## 실행

```bash
ros2 launch mpc_test_world mpc_test_world.launch.py
```

GUI 없이 실행하려면 다음과 같이 실행합니다.

```bash
ros2 launch mpc_test_world mpc_test_world.launch.py gui:=false
```

로봇은 기존 spawn/bringup launch를 함께 실행하면 됩니다. 로봇과 Nav2 노드에는
`use_sim_time: true`를 사용하고, local costmap의 global frame은 `odom`으로 두는
구성이 적합합니다.

충전 도크 위의 권장 초기 pose는 대략 다음과 같습니다.

```text
x: -4.65, y: -3.55, yaw: 3.14159 rad
```

승객 픽업 시험 목표는 `(3.75, -3.4)`, 중앙 작업자 횡단 시험 목표는
`(4.2, 1.1)` 부근으로 설정할 수 있습니다.

## 동적 장애물 조절

`worlds/mpc_test_world.world`에서 각 동적 모델의 플러그인 설정을 수정할 수 있습니다.

- `<speed>`: 직선 속도(m/s)
- `<angular_speed>`: 회전 속도(rad/s)
- `<update_rate>`: 모델 pose 갱신 주기(Hz)
- `<initial_delay>`: 출발 지연 시간(s)
- `<waypoint>` 내부 `<pose>`: 월드 기준 x y z roll pitch yaw
- `<wait>`: 해당 waypoint 도착 후 대기 시간(s)

CPU 사용량을 줄이기 위해 동적 모델 pose는 각각 30 Hz로만 갱신됩니다.
