import os
from pathlib import Path

from ament_index_python.packages import (
    get_package_prefix,
    get_package_share_directory,
)
from launch import LaunchDescription
from launch.actions import (
    DeclareLaunchArgument,
    IncludeLaunchDescription,
    SetEnvironmentVariable,
)
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration


def generate_launch_description():
    package_share = Path(get_package_share_directory("mpc_test_world"))
    package_prefix = Path(get_package_prefix("mpc_test_world"))
    gazebo_share = Path(get_package_share_directory("gazebo_ros"))
    world_path = package_share / "worlds" / "mpc_test_world.world"
    plugin_path = package_prefix / "lib"

    existing_plugin_path = os.environ.get("GAZEBO_PLUGIN_PATH", "")
    gazebo_plugin_path = str(plugin_path)
    if existing_plugin_path:
        gazebo_plugin_path += os.pathsep + existing_plugin_path

    gui = LaunchConfiguration("gui")
    verbose = LaunchConfiguration("verbose")

    gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            str(gazebo_share / "launch" / "gazebo.launch.py")
        ),
        launch_arguments={
            "world": str(world_path),
            "gui": gui,
            "verbose": verbose,
        }.items(),
    )

    return LaunchDescription(
        [
            DeclareLaunchArgument("gui", default_value="true"),
            DeclareLaunchArgument("verbose", default_value="false"),
            SetEnvironmentVariable(
                "GAZEBO_PLUGIN_PATH", gazebo_plugin_path
            ),
            gazebo,
        ]
    )
