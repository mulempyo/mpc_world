#include <algorithm>
#include <cmath>
#include <functional>
#include <memory>
#include <string>
#include <vector>

#include <gazebo/common/Events.hh>
#include <gazebo/common/Plugin.hh>
#include <gazebo/common/Time.hh>
#include <gazebo/gazebo.hh>
#include <gazebo/physics/physics.hh>

#include <ignition/math/Pose3.hh>
#include <sdf/sdf.hh>

namespace gazebo
{

class WaypointMoverPlugin : public ModelPlugin
{
public:
  void Load(physics::ModelPtr model, sdf::ElementPtr sdf) override
  {
    model_ = model;
    world_ = model_->GetWorld();

    speed_ = std::max(0.01, sdf->Get<double>("speed", 0.6).first);
    angular_speed_ = std::max(0.01, sdf->Get<double>("angular_speed", 1.2).first);
    update_rate_ = std::max(1.0, sdf->Get<double>("update_rate", 30.0).first);
    initial_delay_ = std::max(0.0, sdf->Get<double>("initial_delay", 0.0).first);
    loop_ = sdf->Get<bool>("loop", true).first;

    if (!sdf->HasElement("waypoint")) {
      gzerr << "[WaypointMoverPlugin] Model '" << model_->GetName()
            << "' has no waypoints.\n";
      return;
    }

    sdf::ElementPtr waypoint_element = sdf->GetElement("waypoint");
    while (waypoint_element) {
      Waypoint waypoint;
      waypoint.pose = waypoint_element->Get<ignition::math::Pose3d>("pose");
      waypoint.wait = std::max(
        0.0, waypoint_element->Get<double>("wait", 0.0).first);
      waypoints_.push_back(waypoint);
      waypoint_element = waypoint_element->GetNextElement("waypoint");
    }

    if (waypoints_.size() < 2) {
      gzerr << "[WaypointMoverPlugin] Model '" << model_->GetName()
            << "' needs at least two waypoints.\n";
      return;
    }

    // Kinematic links retain collision geometry but are not pulled by gravity.
    for (const auto & link : model_->GetLinks()) {
      link->SetGravityMode(false);
      link->SetKinematic(true);
    }

    model_->SetWorldPose(waypoints_.front().pose);

    const common::Time now = world_->SimTime();
    last_update_time_ = now;
    target_index_ = 1;

    const double first_wait = initial_delay_ + waypoints_.front().wait;
    if (first_wait > 0.0) {
      waiting_ = true;
      wait_end_time_ = now + common::Time(first_wait);
    } else {
      BeginSegment(now);
    }

    update_connection_ = event::Events::ConnectWorldUpdateBegin(
      std::bind(&WaypointMoverPlugin::OnUpdate, this));
  }

private:
  struct Waypoint
  {
    ignition::math::Pose3d pose;
    double wait{0.0};
  };

  static double ShortestYawDifference(double from, double to)
  {
    return std::atan2(std::sin(to - from), std::cos(to - from));
  }

  void BeginSegment(const common::Time & now)
  {
    segment_start_pose_ = model_->WorldPose();
    const ignition::math::Pose3d & target = waypoints_[target_index_].pose;

    const double distance =
      (target.Pos() - segment_start_pose_.Pos()).Length();
    const double yaw_delta = ShortestYawDifference(
      segment_start_pose_.Rot().Yaw(), target.Rot().Yaw());

    segment_duration_ = std::max({
      distance / speed_,
      std::abs(yaw_delta) / angular_speed_,
      0.001});

    segment_start_time_ = now;
    waiting_ = false;
  }

  void FinishSegment(const common::Time & now)
  {
    model_->SetWorldPose(waypoints_[target_index_].pose);
    const double wait = waypoints_[target_index_].wait;

    if (!loop_ && target_index_ + 1 >= waypoints_.size()) {
      finished_ = true;
      return;
    }

    target_index_ = (target_index_ + 1) % waypoints_.size();

    if (wait > 0.0) {
      waiting_ = true;
      wait_end_time_ = now + common::Time(wait);
    } else {
      BeginSegment(now);
    }
  }

  void OnUpdate()
  {
    if (finished_ || waypoints_.size() < 2) {
      return;
    }

    const common::Time now = world_->SimTime();
    const double update_period = 1.0 / update_rate_;

    if ((now - last_update_time_).Double() < update_period) {
      return;
    }
    last_update_time_ = now;

    if (waiting_) {
      if (now < wait_end_time_) {
        return;
      }
      BeginSegment(now);
      return;
    }

    const double elapsed = (now - segment_start_time_).Double();
    const double ratio = std::clamp(elapsed / segment_duration_, 0.0, 1.0);
    const ignition::math::Pose3d & target = waypoints_[target_index_].pose;

    const ignition::math::Vector3d position =
      segment_start_pose_.Pos() * (1.0 - ratio) + target.Pos() * ratio;

    const double start_yaw = segment_start_pose_.Rot().Yaw();
    const double yaw_delta = ShortestYawDifference(
      start_yaw, target.Rot().Yaw());
    const double yaw = start_yaw + yaw_delta * ratio;

    model_->SetWorldPose(ignition::math::Pose3d(
      position, ignition::math::Quaterniond(0.0, 0.0, yaw)));

    if (ratio >= 1.0) {
      FinishSegment(now);
    }
  }

  physics::ModelPtr model_;
  physics::WorldPtr world_;
  event::ConnectionPtr update_connection_;

  std::vector<Waypoint> waypoints_;
  std::size_t target_index_{1};

  ignition::math::Pose3d segment_start_pose_;
  common::Time segment_start_time_;
  common::Time wait_end_time_;
  common::Time last_update_time_;

  double speed_{0.6};
  double angular_speed_{1.2};
  double update_rate_{30.0};
  double initial_delay_{0.0};
  double segment_duration_{1.0};

  bool loop_{true};
  bool waiting_{false};
  bool finished_{false};
};

GZ_REGISTER_MODEL_PLUGIN(WaypointMoverPlugin)

}  // namespace gazebo
