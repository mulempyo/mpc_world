# MPC Multi-Scenario Gazebo Classic Test World

This ROS 2 Humble package provides one Gazebo Classic 11 arena for testing:

- straight tracking;
- circular tracking;
- an S-shaped physical corridor;
- a 90-degree corner;
- a 1.0 m narrow corridor;
- forward/reverse transition in a dead-end bay;
- Omni/Mecanum and 4WIS lateral/diagonal motion;
- three collision-enabled dynamic obstacles.

The moving obstacles are Gazebo models with collision geometry, not
visual-only actors. They are visible to ray sensors and participate in
collision/contact calculations.

## Build and launch

    cd /colcon_ws/src
    unzip mpc_test_world.zip
    cd /colcon_ws
    colcon build --packages-select mpc_test_world
    source install/setup.bash
    ros2 launch mpc_test_world mpc_test_world.launch.py

Launch the robot or spawn its URDF separately. Suggested starts:

- Differential drive: x=-18.0, y=-13.0, yaw=0.0
- Omni/4WIS: x=8.0, y=-12.5, yaw=0.0

Example when a robot description is already available:

    ros2 run gazebo_ros spawn_entity.py \
      -topic robot_description \
      -entity test_robot \
      -x -18.0 -y -13.0 -Y 0.0

## Arena zones

| Test | Approximate region | Marker color |
| --- | --- | --- |
| Straight | x=-18..-4, y=-13 | Yellow |
| Circle | center (11, 9), radius 3.2 m | Blue |
| S curve | x=-18..-4, y=6..10 | Green |
| 90-degree corner | (-2,-12) to (3,-12) to (3,-7) | Orange |
| Narrow corridor | x=-2..6, y=0, clear width about 1.15 m | White |
| Forward/reverse bay | x=-18..-13.2, y=-4 | Purple |
| Omni/4WIS arena | x=7..19, y=-14..-3 | Cyan/magenta |

Recommended route coordinates are in config/test_routes.yaml.

## Dynamic obstacles

1. dynamic_crossing_obstacle crosses the straight lane every 6 seconds.
2. dynamic_corridor_cart shuttles through the narrow corridor every 10 seconds.
3. dynamic_omni_patrol follows a rectangular 20-second patrol.

The movement plugin updates at 50 Hz. To disable an obstacle, remove or comment
out the corresponding model in worlds/mpc_motion_test.world.

## Important test notes

- The 90-degree and S tests deliberately include demanding geometry. Reduce
  reference speed according to v <= omega_max / abs(kappa).
- For reverse testing, the controller must allow negative longitudinal velocity
  and include a forward/reverse mode-selection policy. The corresponding route
  includes signed-speed hints in config/test_routes.yaml.
- Omni/4WIS tests require vx, vy and omega; a differential-drive model cannot
  execute pure lateral segments.
- If the dynamic-plugin library is not found, confirm the workspace is sourced:

      source /colcon_ws/install/setup.bash
      echo "$GAZEBO_PLUGIN_PATH"

## Regenerating the world

The checked-in world can be recreated after changing geometry:

    python3 scripts/generate_world.py worlds/mpc_motion_test.world

This package targets Gazebo Classic 11 through gazebo_ros on ROS 2 Humble. It
is not a modern Gazebo (gz sim) package.
