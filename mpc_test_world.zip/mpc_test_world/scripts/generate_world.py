#!/usr/bin/env python3
"""Generate the Gazebo Classic MPC multi-scenario test world."""

import math
import pathlib
import sys
import xml.etree.ElementTree as ET


COLORS = {
    # Warm, bright oak palette. Inline RGBA is used instead of a Gazebo
    # material script so the world remains self-contained in containers.
    "ground": (0.82, 0.68, 0.48, 1.0),
    "wood": (0.76, 0.52, 0.29, 1.0),
    "wood_light": (0.88, 0.72, 0.49, 1.0),
    "wood_dark": (0.58, 0.36, 0.18, 1.0),
    "wood_seam": (0.68, 0.46, 0.27, 1.0),
    "yellow": (1.00, 0.75, 0.05, 1.0),
    "blue": (0.10, 0.45, 1.00, 1.0),
    "green": (0.05, 0.90, 0.35, 1.0),
    "orange": (1.00, 0.35, 0.05, 1.0),
    "white": (0.90, 0.90, 0.90, 1.0),
    "purple": (0.75, 0.20, 1.00, 1.0),
    "cyan": (0.05, 0.90, 0.95, 1.0),
    "red": (0.95, 0.08, 0.08, 1.0),
    "magenta": (1.00, 0.05, 0.65, 1.0),
}


def element(parent, tag, text=None, **attributes):
    child = ET.SubElement(parent, tag, attributes)
    if text is not None:
        child.text = str(text)
    return child


def vector_text(values):
    return " ".join(f"{value:.6f}" for value in values)


def add_material(visual, rgba):
    material = element(visual, "material")
    element(material, "ambient", vector_text(rgba))
    element(material, "diffuse", vector_text(rgba))
    element(material, "specular", "0.1 0.1 0.1 1")


def add_box_link(
    model,
    name,
    pose,
    size,
    color,
    collision=True,
    cast_shadows=True,
):
    link = element(model, "link", name=name)
    element(link, "pose", vector_text(pose))

    if collision:
        collision_element = element(link, "collision", name=f"{name}_collision")
        geometry = element(collision_element, "geometry")
        box = element(geometry, "box")
        element(box, "size", vector_text(size))
        surface = element(collision_element, "surface")
        friction = element(surface, "friction")
        ode = element(friction, "ode")
        element(ode, "mu", "1.0")
        element(ode, "mu2", "1.0")

    visual = element(link, "visual", name=f"{name}_visual")
    geometry = element(visual, "geometry")
    box = element(geometry, "box")
    element(box, "size", vector_text(size))
    element(visual, "cast_shadows", str(cast_shadows).lower())
    add_material(visual, COLORS[color])
    return link


def add_cylinder_link(
    model,
    name,
    pose,
    radius,
    length,
    color,
    collision=True,
):
    link = element(model, "link", name=name)
    element(link, "pose", vector_text(pose))

    if collision:
        collision_element = element(link, "collision", name=f"{name}_collision")
        geometry = element(collision_element, "geometry")
        cylinder = element(geometry, "cylinder")
        element(cylinder, "radius", f"{radius:.6f}")
        element(cylinder, "length", f"{length:.6f}")

    visual = element(link, "visual", name=f"{name}_visual")
    geometry = element(visual, "geometry")
    cylinder = element(geometry, "cylinder")
    element(cylinder, "radius", f"{radius:.6f}")
    element(cylinder, "length", f"{length:.6f}")
    add_material(visual, COLORS[color])
    return link


def add_segment(
    model,
    name,
    start,
    end,
    width,
    height,
    color,
    collision,
):
    x0, y0 = start
    x1, y1 = end
    dx = x1 - x0
    dy = y1 - y0
    length = math.hypot(dx, dy)
    yaw = math.atan2(dy, dx)
    return add_box_link(
        model,
        name,
        ((x0 + x1) * 0.5, (y0 + y1) * 0.5, height * 0.5, 0, 0, yaw),
        (length, width, height),
        color,
        collision=collision,
        cast_shadows=collision,
    )


def add_polyline(
    model,
    name,
    points,
    width,
    height,
    color,
    collision=False,
):
    """Add a polyline as overlapping box segments."""
    for index in range(len(points) - 1):
        add_segment(
            model,
            f"{name}_{index:03d}",
            points[index],
            points[index + 1],
            width,
            height,
            color,
            collision,
        )


def offset_polyline(points, offsets):
    """Offset every point along an averaged local normal."""
    if isinstance(offsets, (int, float)):
        offsets = [float(offsets)] * len(points)
    if len(offsets) != len(points):
        raise ValueError("offset count must match the point count")

    result = []
    for index, point in enumerate(points):
        previous = points[max(0, index - 1)]
        following = points[min(len(points) - 1, index + 1)]
        dx = following[0] - previous[0]
        dy = following[1] - previous[1]
        length = math.hypot(dx, dy)
        if length < 1.0e-9:
            raise ValueError("consecutive corridor points must be different")
        nx = -dy / length
        ny = dx / length
        result.append((
            point[0] + offsets[index] * nx,
            point[1] + offsets[index] * ny,
        ))
    return result


def add_corridor(
    model,
    name,
    points,
    half_width,
    guide_color,
    wall_color="wood",
    wall_height=0.55,
):
    """Add a colored guide with collision walls on both sides."""
    if isinstance(half_width, (int, float)):
        widths = [float(half_width)] * len(points)
    else:
        widths = list(half_width)

    left = offset_polyline(points, widths)
    right = offset_polyline(points, [-value for value in widths])
    add_polyline(model, f"{name}_guide", points, 0.085, 0.026, guide_color)
    add_polyline(
        model, f"{name}_left_wall", left, 0.18, wall_height,
        wall_color, collision=True
    )
    add_polyline(
        model, f"{name}_right_wall", right, 0.18, wall_height,
        wall_color, collision=True
    )


def add_dynamic_model(
    world,
    name,
    shape,
    size,
    color,
    waypoints,
    update_rate=50.0,
    start_delay=0.0,
):
    model = element(world, "model", name=name)
    element(model, "static", "false")
    element(model, "allow_auto_disable", "false")
    element(model, "pose", vector_text(waypoints[0][1]))

    link = element(model, "link", name="body")
    element(link, "gravity", "false")
    element(link, "kinematic", "true")
    inertial = element(link, "inertial")
    element(inertial, "mass", "20.0")
    inertia = element(inertial, "inertia")
    element(inertia, "ixx", "1.0")
    element(inertia, "iyy", "1.0")
    element(inertia, "izz", "1.0")

    collision = element(link, "collision", name="collision")
    geometry = element(collision, "geometry")
    visual = element(link, "visual", name="visual")
    visual_geometry = element(visual, "geometry")

    if shape == "box":
        box = element(geometry, "box")
        element(box, "size", vector_text(size))
        visual_box = element(visual_geometry, "box")
        element(visual_box, "size", vector_text(size))
    elif shape == "cylinder":
        radius, length = size
        cylinder = element(geometry, "cylinder")
        element(cylinder, "radius", radius)
        element(cylinder, "length", length)
        visual_cylinder = element(visual_geometry, "cylinder")
        element(visual_cylinder, "radius", radius)
        element(visual_cylinder, "length", length)
    else:
        raise ValueError(f"Unsupported shape: {shape}")

    add_material(visual, COLORS[color])
    plugin = element(
        model,
        "plugin",
        name=f"{name}_trajectory",
        filename="libwaypoint_obstacle_plugin.so",
    )
    element(plugin, "loop", "true")
    element(plugin, "update_rate", update_rate)
    element(plugin, "start_delay", start_delay)

    for time_value, pose in waypoints:
        waypoint = element(plugin, "waypoint")
        element(waypoint, "time", time_value)
        element(waypoint, "pose", vector_text(pose))




def build_world():
    """Build one connected, bright wooden MPC test course."""
    sdf = ET.Element("sdf", version="1.6")
    world = element(sdf, "world", name="mpc_motion_test")
    element(world, "gravity", "0 0 -9.81")
    element(world, "magnetic_field", "6e-6 2.3e-5 -4.2e-5")

    physics = element(world, "physics", name="default_physics", type="ode")
    element(physics, "max_step_size", "0.001")
    element(physics, "real_time_factor", "1.0")
    element(physics, "real_time_update_rate", "1000")

    scene = element(world, "scene")
    element(scene, "ambient", "0.78 0.78 0.74 1")
    element(scene, "background", "0.82 0.90 1.00 1")
    element(scene, "shadows", "false")

    gui = element(world, "gui", fullscreen="0")
    camera = element(gui, "camera", name="overview_camera")
    element(camera, "pose", "0 -39 46 0 0.84 1.57")
    element(camera, "view_controller", "orbit")

    sun = element(world, "light", name="sun", type="directional")
    element(sun, "cast_shadows", "false")
    element(sun, "pose", "0 0 24 0 0 0")
    element(sun, "diffuse", "1.0 0.98 0.92 1")
    element(sun, "specular", "0.25 0.22 0.18 1")
    element(sun, "direction", "-0.35 0.20 -0.92")

    arena = element(world, "model", name="mpc_test_arena")
    element(arena, "static", "true")
    add_box_link(
        arena,
        "ground",
        (0, 0, -0.05, 0, 0, 0),
        (54, 38, 0.1),
        "ground",
        collision=True,
        cast_shadows=False,
    )

    # Thin visual-only seams make the floor look like light oak boards while
    # keeping the collision plane perfectly flat.
    for index, y in enumerate(range(-18, 19, 2)):
        add_segment(
            arena,
            f"floor_seam_{index:02d}",
            (-26.7, y),
            (26.7, y),
            0.025,
            0.008,
            "wood_seam",
            False,
        )

    # Bright wooden outer safety boundary.
    add_box_link(
        arena, "boundary_n", (0, 18.9, 0.6, 0, 0, 0),
        (54, 0.22, 1.2), "wood_light"
    )
    add_box_link(
        arena, "boundary_s", (0, -18.9, 0.6, 0, 0, 0),
        (54, 0.22, 1.2), "wood_light"
    )
    add_box_link(
        arena, "boundary_e", (26.9, 0, 0.6, 0, 0, 0),
        (0.22, 38, 1.2), "wood_light"
    )
    add_box_link(
        arena, "boundary_w", (-26.9, 0, 0.6, 0, 0, 0),
        (0.22, 38, 1.2), "wood_light"
    )

    # 1) Straight. The gaps at x=-18 admit the crossing obstacle.
    add_segment(
        arena, "straight_guide", (-23, -15), (-12, -15),
        0.085, 0.026, "yellow", False
    )
    for side, y in (("south", -16.3), ("north", -13.7)):
        add_segment(
            arena, f"straight_{side}_wall_a", (-23, y), (-19, y),
            0.18, 0.55, "wood", True
        )
        add_segment(
            arena, f"straight_{side}_wall_b", (-17, y), (-12, y),
            0.18, 0.55, "wood", True
        )
    add_box_link(
        arena, "course_start_pad", (-22.5, -15, 0.015, 0, 0, 0),
        (1.0, 1.3, 0.03), "yellow", False
    )

    # 2) Smooth 90-degree corner: (-12,-15) -> (-9,-12).
    corner_center = (-12.0, -12.0)
    corner_points = []
    for index in range(13):
        angle = -0.5 * math.pi + 0.5 * math.pi * index / 12.0
        corner_points.append((
            corner_center[0] + 3.0 * math.cos(angle),
            corner_center[1] + 3.0 * math.sin(angle),
        ))
    add_corridor(arena, "corner", corner_points, 1.3, "orange")

    # 3) Narrow corridor. It tapers to a 1.5 m clear section and ends exactly
    # at the S-curve entrance.
    narrow_points = [
        (-9.0, -12.0),
        (-9.0, -11.0),
        (-9.0, -10.0),
        (-9.0, -4.0),
    ]
    add_corridor(
        arena,
        "narrow",
        narrow_points,
        [1.3, 1.05, 0.84, 0.84],
        "white",
        wall_height=0.75,
    )

    # 4) Vertical S corridor. Both endpoints are tangent to their adjoining
    # sections, and the envelope widens after the narrow section.
    s_points = []
    s_widths = []
    for index in range(33):
        ratio = index / 32.0
        x = (
            -9.0
            + 2.0
            * math.sin(2.0 * math.pi * ratio)
            * math.sin(math.pi * ratio) ** 2
        )
        y = -4.0 + 14.0 * ratio
        s_points.append((x, y))
        s_widths.append(0.84 + 0.46 * min(1.0, ratio / 0.18))
    add_corridor(arena, "s_curve", s_points, s_widths, "green")

    # 5) Connected clockwise 270-degree circular arc.  The circle is placed
    # to the right of the S corridor so the later connector never crosses an
    # earlier part of the course.
    circle_center = (-4.0, 10.0)
    circle_points = []
    for index in range(37):
        angle = math.pi - 1.5 * math.pi * index / 36.0
        circle_points.append((
            circle_center[0] + 5.0 * math.cos(angle),
            circle_center[1] + 5.0 * math.sin(angle),
        ))
    add_corridor(arena, "circle", circle_points, 1.3, "blue")
    add_cylinder_link(
        arena,
        "circle_center_island",
        (circle_center[0], circle_center[1], 0.40, 0, 0, 0),
        3.05,
        0.80,
        "wood_light",
        collision=True,
    )

    # 6) Two smooth quarter turns lead from the west-facing circle exit to an
    # east-facing connector at y=-2.  This transition remains clear of the S
    # corridor and removes the former four-way self-intersection.
    transition_points = []
    for index in range(13):
        angle = 0.5 * math.pi + 0.5 * math.pi * index / 12.0
        transition_points.append((
            -4.0 + 1.5 * math.cos(angle),
            3.5 + 1.5 * math.sin(angle),
        ))
    transition_points.append((-5.5, -0.5))
    for index in range(1, 13):
        angle = math.pi + 0.5 * math.pi * index / 12.0
        transition_points.append((
            -4.0 + 1.5 * math.cos(angle),
            -0.5 + 1.5 * math.sin(angle),
        ))
    transition_widths = []
    for index in range(len(transition_points)):
        edge_ratio = min(
            1.0,
            min(index, len(transition_points) - 1 - index) / 4.0,
        )
        transition_widths.append(1.3 - 0.55 * edge_ratio)
    add_corridor(
        arena,
        "circle_exit_transition",
        transition_points,
        transition_widths,
        "yellow",
    )

    # 7) Eastbound connector. Its south wall has an opening for the reverse
    # bay, preserving a single connected physical course.
    add_segment(
        arena, "connector_guide", (-4, -2), (5, -2),
        0.085, 0.026, "yellow", False
    )
    add_segment(
        arena, "connector_north_wall", (-4, -0.7), (4.5, -0.7),
        0.18, 0.55, "wood", True
    )
    add_segment(
        arena, "connector_south_wall_a", (-4, -3.3), (-1.3, -3.3),
        0.18, 0.55, "wood", True
    )
    add_segment(
        arena, "connector_south_wall_b", (1.3, -3.3), (4.5, -3.3),
        0.18, 0.55, "wood", True
    )

    # 8) Connected dead-end bay for a forward/reverse transition.
    add_segment(
        arena, "reverse_guide", (0, -2), (0, -10.8),
        0.085, 0.026, "purple", False
    )
    add_segment(
        arena, "reverse_west_wall", (-1.3, -3.3), (-1.3, -11.6),
        0.18, 0.75, "wood", True
    )
    add_segment(
        arena, "reverse_east_wall", (1.3, -3.3), (1.3, -11.6),
        0.18, 0.75, "wood", True
    )
    add_segment(
        arena, "reverse_back_wall", (-1.3, -11.6), (1.3, -11.6),
        0.18, 0.75, "wood_dark", True
    )
    add_box_link(
        arena, "reverse_target_pad", (0, -10.8, 0.015, 0, 0, 0),
        (1.2, 0.8, 0.03), "purple", False
    )

    # 9) Omni/4WIS zone, connected at (4.5,-2). Its marked sequence is pure
    # lateral -> diagonal -> diagonal -> pure lateral with yaw held at zero.
    west_x, east_x, south_y, north_y = (4.5, 23.5, -7.0, 15.5)
    add_segment(
        arena, "omni_west_wall_s", (west_x, south_y), (west_x, -3.3),
        0.20, 0.65, "wood_light", True
    )
    add_segment(
        arena, "omni_west_wall_n", (west_x, -0.7), (west_x, north_y),
        0.20, 0.65, "wood_light", True
    )
    add_segment(
        arena, "omni_east_wall", (east_x, south_y), (east_x, north_y),
        0.20, 0.65, "wood_light", True
    )
    add_segment(
        arena, "omni_south_wall", (west_x, south_y), (east_x, south_y),
        0.20, 0.65, "wood_light", True
    )
    add_segment(
        arena, "omni_north_wall", (west_x, north_y), (east_x, north_y),
        0.20, 0.65, "wood_light", True
    )

    for x in range(5, 24, 2):
        add_segment(
            arena, f"omni_grid_x_{x}", (x, -6.7), (x, 15.2),
            0.032, 0.018, "cyan", False
        )
    for y in range(-6, 16, 2):
        add_segment(
            arena, f"omni_grid_y_{y}", (4.8, y), (23.2, y),
            0.032, 0.018, "cyan", False
        )

    add_segment(
        arena, "omni_entry", (4.5, -2), (6, -2),
        0.085, 0.026, "cyan", False
    )
    add_segment(
        arena, "omni_lateral_a", (6, -2), (6, 8),
        0.095, 0.028, "cyan", False
    )
    add_segment(
        arena, "omni_diagonal_a", (6, 8), (13, 14),
        0.095, 0.028, "magenta", False
    )
    add_segment(
        arena, "omni_diagonal_b", (13, 14), (21, 7),
        0.095, 0.028, "magenta", False
    )
    add_segment(
        arena, "omni_lateral_b", (21, 7), (21, -4),
        0.095, 0.028, "cyan", False
    )
    add_box_link(
        arena, "omni_start_pad", (6, -2, 0.015, 0, 0, 0),
        (1.0, 1.0, 0.03), "cyan", False
    )
    add_box_link(
        arena, "omni_goal_pad", (21, -4, 0.015, 0, 0, 0),
        (1.0, 1.0, 0.03), "magenta", False
    )
    for index, position in enumerate(((9, 2), (15, 8), (18, -2))):
        add_cylinder_link(
            arena,
            f"omni_bollard_{index}",
            (position[0], position[1], 0.45, 0, 0, 0),
            0.28,
            0.9,
            "orange",
            collision=True,
        )

    # Dynamic obstacle 1: crosses the first straight through its wall gaps.
    add_dynamic_model(
        world,
        "dynamic_crossing_obstacle",
        "box",
        (0.45, 0.45, 1.60),
        "red",
        [
            (0.0, (-18.0, -17.2, 0.80, 0, 0, math.pi / 2)),
            (3.0, (-18.0, -13.0, 0.80, 0, 0, math.pi / 2)),
            (6.0, (-18.0, -17.2, 0.80, 0, 0, -math.pi / 2)),
        ],
        start_delay=1.0,
    )

    # Dynamic obstacle 2: longitudinal shuttle inside the narrow corridor.
    add_dynamic_model(
        world,
        "dynamic_corridor_cart",
        "cylinder",
        (0.32, 0.90),
        "orange",
        [
            (0.0, (-9.0, -11.0, 0.45, 0, 0, math.pi / 2)),
            (5.0, (-9.0, -5.0, 0.45, 0, 0, math.pi / 2)),
            (10.0, (-9.0, -11.0, 0.45, 0, 0, -math.pi / 2)),
        ],
        start_delay=2.0,
    )

    # Dynamic obstacle 3: rectangular patrol in the Omni/4WIS arena.
    add_dynamic_model(
        world,
        "dynamic_omni_patrol",
        "box",
        (0.80, 0.55, 0.70),
        "red",
        [
            (0.0, (6.0, -6.0, 0.35, 0, 0, 0)),
            (6.0, (22.0, -6.0, 0.35, 0, 0, math.pi / 2)),
            (10.0, (22.0, 14.5, 0.35, 0, 0, math.pi)),
            (16.0, (6.0, 14.5, 0.35, 0, 0, -math.pi / 2)),
            (20.0, (6.0, -6.0, 0.35, 0, 0, 0)),
        ],
    )

    return ET.ElementTree(sdf)


def main():
    if len(sys.argv) > 1:
        output_path = pathlib.Path(sys.argv[1])
    else:
        output_path = (
            pathlib.Path(__file__).resolve().parents[1]
            / "worlds"
            / "mpc_motion_test.world"
        )

    output_path.parent.mkdir(parents=True, exist_ok=True)
    tree = build_world()
    ET.indent(tree, space="  ")
    tree.write(output_path, encoding="utf-8", xml_declaration=True)
    print(output_path)


if __name__ == "__main__":
    main()
