#!/usr/bin/env python3
"""Generate the Gazebo Classic MPC multi-scenario test world."""

import math
import pathlib
import sys
import xml.etree.ElementTree as ET


COLORS = {
    "ground": (0.16, 0.18, 0.20, 1.0),
    "wall": (0.50, 0.52, 0.55, 1.0),
    "yellow": (1.00, 0.75, 0.05, 1.0),
    "blue": (0.10, 0.45, 1.00, 1.0),
    "green": (0.05, 0.90, 0.35, 1.0),
    "orange": (1.00, 0.35, 0.05, 1.0),
    "white": (0.90, 0.90, 0.90, 1.0),
    "purple": (0.75, 0.20, 1.00, 1.0),
    "cyan": (0.05, 0.90, 0.95, 1.0),
    "red": (0.95, 0.08, 0.08, 1.0),
    "magenta": (1.00, 0.05, 0.65, 1.0),
}


def element(parent, tag, text=None, **attributes):
    child = ET.SubElement(parent, tag, attributes)
    if text is not None:
        child.text = str(text)
    return child


def vector_text(values):
    return " ".join(f"{value:.6f}" for value in values)


def add_material(visual, rgba):
    material = element(visual, "material")
    element(material, "ambient", vector_text(rgba))
    element(material, "diffuse", vector_text(rgba))
    element(material, "specular", "0.1 0.1 0.1 1")


def add_box_link(
    model,
    name,
    pose,
    size,
    color,
    collision=True,
    cast_shadows=True,
):
    link = element(model, "link", name=name)
    element(link, "pose", vector_text(pose))

    if collision:
        collision_element = element(link, "collision", name=f"{name}_collision")
        geometry = element(collision_element, "geometry")
        box = element(geometry, "box")
        element(box, "size", vector_text(size))
        surface = element(collision_element, "surface")
        friction = element(surface, "friction")
        ode = element(friction, "ode")
        element(ode, "mu", "1.0")
        element(ode, "mu2", "1.0")

    visual = element(link, "visual", name=f"{name}_visual")
    geometry = element(visual, "geometry")
    box = element(geometry, "box")
    element(box, "size", vector_text(size))
    element(visual, "cast_shadows", str(cast_shadows).lower())
    add_material(visual, COLORS[color])
    return link


def add_cylinder_link(
    model,
    name,
    pose,
    radius,
    length,
    color,
    collision=True,
):
    link = element(model, "link", name=name)
    element(link, "pose", vector_text(pose))

    if collision:
        collision_element = element(link, "collision", name=f"{name}_collision")
        geometry = element(collision_element, "geometry")
        cylinder = element(geometry, "cylinder")
        element(cylinder, "radius", f"{radius:.6f}")
        element(cylinder, "length", f"{length:.6f}")

    visual = element(link, "visual", name=f"{name}_visual")
    geometry = element(visual, "geometry")
    cylinder = element(geometry, "cylinder")
    element(cylinder, "radius", f"{radius:.6f}")
    element(cylinder, "length", f"{length:.6f}")
    add_material(visual, COLORS[color])
    return link


def add_segment(
    model,
    name,
    start,
    end,
    width,
    height,
    color,
    collision,
):
    x0, y0 = start
    x1, y1 = end
    dx = x1 - x0
    dy = y1 - y0
    length = math.hypot(dx, dy)
    yaw = math.atan2(dy, dx)
    return add_box_link(
        model,
        name,
        ((x0 + x1) * 0.5, (y0 + y1) * 0.5, height * 0.5, 0, 0, yaw),
        (length, width, height),
        color,
        collision=collision,
        cast_shadows=collision,
    )


def add_dynamic_model(
    world,
    name,
    shape,
    size,
    color,
    waypoints,
    update_rate=50.0,
    start_delay=0.0,
):
    model = element(world, "model", name=name)
    element(model, "static", "false")
    element(model, "allow_auto_disable", "false")
    element(model, "pose", vector_text(waypoints[0][1]))

    link = element(model, "link", name="body")
    element(link, "gravity", "false")
    element(link, "kinematic", "true")
    inertial = element(link, "inertial")
    element(inertial, "mass", "20.0")
    inertia = element(inertial, "inertia")
    element(inertia, "ixx", "1.0")
    element(inertia, "iyy", "1.0")
    element(inertia, "izz", "1.0")

    collision = element(link, "collision", name="collision")
    geometry = element(collision, "geometry")
    visual = element(link, "visual", name="visual")
    visual_geometry = element(visual, "geometry")

    if shape == "box":
        box = element(geometry, "box")
        element(box, "size", vector_text(size))
        visual_box = element(visual_geometry, "box")
        element(visual_box, "size", vector_text(size))
    elif shape == "cylinder":
        radius, length = size
        cylinder = element(geometry, "cylinder")
        element(cylinder, "radius", radius)
        element(cylinder, "length", length)
        visual_cylinder = element(visual_geometry, "cylinder")
        element(visual_cylinder, "radius", radius)
        element(visual_cylinder, "length", length)
    else:
        raise ValueError(f"Unsupported shape: {shape}")

    add_material(visual, COLORS[color])
    plugin = element(
        model,
        "plugin",
        name=f"{name}_trajectory",
        filename="libwaypoint_obstacle_plugin.so",
    )
    element(plugin, "loop", "true")
    element(plugin, "update_rate", update_rate)
    element(plugin, "start_delay", start_delay)

    for time_value, pose in waypoints:
        waypoint = element(plugin, "waypoint")
        element(waypoint, "time", time_value)
        element(waypoint, "pose", vector_text(pose))


def build_world():
    sdf = ET.Element("sdf", version="1.6")
    world = element(sdf, "world", name="mpc_motion_test")
    element(world, "gravity", "0 0 -9.81")
    element(world, "magnetic_field", "6e-6 2.3e-5 -4.2e-5")

    physics = element(world, "physics", name="default_physics", type="ode")
    element(physics, "max_step_size", "0.001")
    element(physics, "real_time_factor", "1.0")
    element(physics, "real_time_update_rate", "1000")

    scene = element(world, "scene")
    element(scene, "ambient", "0.45 0.45 0.45 1")
    element(scene, "background", "0.70 0.78 0.90 1")
    element(scene, "shadows", "true")

    gui = element(world, "gui", fullscreen="0")
    camera = element(gui, "camera", name="overview_camera")
    element(camera, "pose", "0 -25 33 0 0.82 1.57")
    element(camera, "view_controller", "orbit")

    sun = element(world, "light", name="sun", type="directional")
    element(sun, "cast_shadows", "true")
    element(sun, "pose", "0 0 20 0 0 0")
    element(sun, "diffuse", "0.9 0.9 0.9 1")
    element(sun, "specular", "0.2 0.2 0.2 1")
    element(sun, "direction", "-0.4 0.2 -0.9")

    arena = element(world, "model", name="mpc_test_arena")
    element(arena, "static", "true")
    add_box_link(
        arena, "ground", (0, 0, -0.05, 0, 0, 0),
        (42, 32, 0.1), "ground", collision=True
    )

    # Outer safety boundary.
    add_box_link(arena, "boundary_n", (0, 15.9, 0.6, 0, 0, 0), (42, 0.2, 1.2), "wall")
    add_box_link(arena, "boundary_s", (0, -15.9, 0.6, 0, 0, 0), (42, 0.2, 1.2), "wall")
    add_box_link(arena, "boundary_e", (20.9, 0, 0.6, 0, 0, 0), (0.2, 32, 1.2), "wall")
    add_box_link(arena, "boundary_w", (-20.9, 0, 0.6, 0, 0, 0), (0.2, 32, 1.2), "wall")

    # 1) Straight lane with a crossing gap.
    add_segment(arena, "straight_guide", (-18, -13), (-4, -13), 0.08, 0.025, "yellow", False)
    for side, y in (("lower", -14.2), ("upper", -11.8)):
        add_segment(arena, f"straight_{side}_wall_a", (-18, y), (-12, y), 0.16, 0.45, "wall", True)
        add_segment(arena, f"straight_{side}_wall_b", (-10, y), (-4, y), 0.16, 0.45, "wall", True)
    add_box_link(arena, "straight_start_pad", (-18, -13, 0.015, 0, 0, 0), (0.8, 1.2, 0.03), "yellow", False)

    # 2) Circular guide around a physical center island.
    circle_center = (11.0, 9.0)
    circle_radius = 3.2
    circle_segments = 36
    circle_points = []
    for index in range(circle_segments + 1):
        angle = 2.0 * math.pi * index / circle_segments
        circle_points.append((
            circle_center[0] + circle_radius * math.cos(angle),
            circle_center[1] + circle_radius * math.sin(angle),
        ))
    for index in range(circle_segments):
        add_segment(
            arena, f"circle_guide_{index:02d}",
            circle_points[index], circle_points[index + 1],
            0.08, 0.025, "blue", False
        )
    add_cylinder_link(
        arena, "circle_center_island",
        (circle_center[0], circle_center[1], 0.45, 0, 0, 0),
        2.1, 0.9, "wall", collision=True
    )

    # 3) Physical S corridor and center guide.
    s_points = []
    for index in range(41):
        ratio = index / 40.0
        x = -18.0 + 14.0 * ratio
        y = 8.0 + 2.0 * math.sin(2.0 * math.pi * ratio)
        s_points.append((x, y))

    corridor_half_width = 1.15
    for index in range(len(s_points) - 1):
        p0 = s_points[index]
        p1 = s_points[index + 1]
        dx = p1[0] - p0[0]
        dy = p1[1] - p0[1]
        length = math.hypot(dx, dy)
        nx = -dy / length
        ny = dx / length
        add_segment(arena, f"s_guide_{index:02d}", p0, p1, 0.07, 0.025, "green", False)
        add_segment(
            arena, f"s_left_wall_{index:02d}",
            (p0[0] + corridor_half_width * nx, p0[1] + corridor_half_width * ny),
            (p1[0] + corridor_half_width * nx, p1[1] + corridor_half_width * ny),
            0.14, 0.45, "wall", True
        )
        add_segment(
            arena, f"s_right_wall_{index:02d}",
            (p0[0] - corridor_half_width * nx, p0[1] - corridor_half_width * ny),
            (p1[0] - corridor_half_width * nx, p1[1] - corridor_half_width * ny),
            0.14, 0.45, "wall", True
        )

    # 4) Ninety-degree L corner.
    add_segment(arena, "corner_guide_h", (-2, -12), (3, -12), 0.08, 0.025, "orange", False)
    add_segment(arena, "corner_guide_v", (3, -12), (3, -7), 0.08, 0.025, "orange", False)
    add_segment(arena, "corner_lower_wall", (-2, -13.1), (4.1, -13.1), 0.16, 0.55, "wall", True)
    add_segment(arena, "corner_inner_h_wall", (-2, -10.9), (1.9, -10.9), 0.16, 0.55, "wall", True)
    add_segment(arena, "corner_inner_v_wall", (1.9, -10.9), (1.9, -7), 0.16, 0.55, "wall", True)
    add_segment(arena, "corner_outer_v_wall", (4.1, -13.1), (4.1, -7), 0.16, 0.55, "wall", True)

    # 5) One-meter narrow corridor.
    add_segment(arena, "narrow_guide", (-2, 0), (6, 0), 0.06, 0.025, "white", False)
    add_segment(arena, "narrow_wall_n", (-2, 0.65), (6, 0.65), 0.15, 0.75, "wall", True)
    add_segment(arena, "narrow_wall_s", (-2, -0.65), (6, -0.65), 0.15, 0.75, "wall", True)

    # 6) Dead-end bay for forward/reverse transitions.
    add_segment(arena, "reverse_guide", (-17.5, -4), (-13.2, -4), 0.08, 0.025, "purple", False)
    add_segment(arena, "reverse_back_wall", (-18, -5), (-18, -3), 0.18, 0.75, "wall", True)
    add_segment(arena, "reverse_side_wall_s", (-18, -5), (-13.2, -5), 0.18, 0.75, "wall", True)
    add_segment(arena, "reverse_side_wall_n", (-18, -3), (-13.2, -3), 0.18, 0.75, "wall", True)
    add_box_link(arena, "reverse_target_pad", (-17.4, -4, 0.015, 0, 0, 0), (0.8, 1.2, 0.03), "purple", False)

    # 7) Omni / 4WIS lateral and diagonal arena.
    for x in range(7, 20, 2):
        add_segment(arena, f"omni_grid_x_{x}", (x, -14), (x, -3), 0.035, 0.02, "cyan", False)
    for y in range(-14, -2, 2):
        add_segment(arena, f"omni_grid_y_{abs(y)}", (7, y), (19, y), 0.035, 0.02, "cyan", False)
    add_segment(arena, "omni_diagonal_a", (8, -13), (18, -4), 0.08, 0.025, "magenta", False)
    add_segment(arena, "omni_diagonal_b", (8, -4), (18, -13), 0.08, 0.025, "magenta", False)
    add_box_link(arena, "omni_start_pad", (8, -12.5, 0.015, 0, 0, 0), (1.0, 1.0, 0.03), "cyan", False)
    add_box_link(arena, "omni_goal_pad", (18, -4, 0.015, 0, 0, 0), (1.0, 1.0, 0.03), "magenta", False)
    add_segment(arena, "omni_offset_wall_a", (11, -14), (11, -8), 0.20, 0.80, "wall", True)
    add_segment(arena, "omni_offset_wall_b", (15, -9), (15, -3), 0.20, 0.80, "wall", True)
    for index, position in enumerate(((9, -7), (13, -11), (17, -7))):
        add_cylinder_link(
            arena, f"omni_bollard_{index}",
            (position[0], position[1], 0.45, 0, 0, 0),
            0.28, 0.9, "orange", collision=True
        )

    # Dynamic obstacle 1: straight-lane crossing.
    add_dynamic_model(
        world, "dynamic_crossing_obstacle", "box",
        (0.45, 0.45, 1.60), "red",
        [
            (0.0, (-11.0, -14.8, 0.80, 0, 0, math.pi / 2)),
            (3.0, (-11.0, -11.2, 0.80, 0, 0, math.pi / 2)),
            (6.0, (-11.0, -14.8, 0.80, 0, 0, -math.pi / 2)),
        ],
        start_delay=1.0,
    )

    # Dynamic obstacle 2: narrow-corridor shuttle.
    add_dynamic_model(
        world, "dynamic_corridor_cart", "cylinder",
        (0.32, 0.90), "orange",
        [
            (0.0, (-1.2, 0.0, 0.45, 0, 0, 0)),
            (5.0, (5.2, 0.0, 0.45, 0, 0, 0)),
            (10.0, (-1.2, 0.0, 0.45, 0, 0, math.pi)),
        ],
        start_delay=2.0,
    )

    # Dynamic obstacle 3: Omni/4WIS rectangular patrol.
    add_dynamic_model(
        world, "dynamic_omni_patrol", "box",
        (0.80, 0.55, 0.70), "red",
        [
            (0.0, (8.0, -13.5, 0.35, 0, 0, 0)),
            (6.0, (18.5, -13.5, 0.35, 0, 0, math.pi / 2)),
            (10.0, (18.5, -3.5, 0.35, 0, 0, math.pi)),
            (16.0, (8.0, -3.5, 0.35, 0, 0, -math.pi / 2)),
            (20.0, (8.0, -13.5, 0.35, 0, 0, 0)),
        ],
    )

    return ET.ElementTree(sdf)


def main():
    if len(sys.argv) > 1:
        output_path = pathlib.Path(sys.argv[1])
    else:
        output_path = (
            pathlib.Path(__file__).resolve().parents[1]
            / "worlds"
            / "mpc_motion_test.world"
        )

    output_path.parent.mkdir(parents=True, exist_ok=True)
    tree = build_world()
    ET.indent(tree, space="  ")
    tree.write(output_path, encoding="utf-8", xml_declaration=True)
    print(output_path)


if __name__ == "__main__":
    main()
