#include <algorithm>
#include <cmath>
#include <functional>
#include <string>
#include <utility>
#include <vector>

#include <gazebo/common/Events.hh>
#include <gazebo/common/Time.hh>
#include <gazebo/gazebo.hh>
#include <gazebo/physics/physics.hh>
#include <ignition/math/Pose3.hh>
#include <sdf/sdf.hh>

namespace gazebo
{

class WaypointObstaclePlugin final : public ModelPlugin
{
public:
  void Load(physics::ModelPtr model, sdf::ElementPtr sdf) override
  {
    model_ = std::move(model);
    world_ = model_->GetWorld();

    if (sdf->HasElement("loop"))
    {
      loop_ = sdf->Get<bool>("loop");
    }
    if (sdf->HasElement("update_rate"))
    {
      update_rate_ = std::max(1.0, sdf->Get<double>("update_rate"));
    }
    if (sdf->HasElement("start_delay"))
    {
      start_delay_ = std::max(0.0, sdf->Get<double>("start_delay"));
    }

    if (!sdf->HasElement("waypoint"))
    {
      gzerr << "[WaypointObstaclePlugin] Model '" << model_->GetName()
            << "' has no <waypoint> elements.\n";
      return;
    }

    sdf::ElementPtr waypoint_element = sdf->GetElement("waypoint");
    while (waypoint_element)
    {
      Waypoint waypoint;
      waypoint.time = waypoint_element->Get<double>("time");
      waypoint.pose =
        waypoint_element->Get<ignition::math::Pose3d>("pose");

      if (std::isfinite(waypoint.time))
      {
        waypoints_.push_back(waypoint);
      }
      waypoint_element =
        waypoint_element->GetNextElement("waypoint");
    }

    std::sort(
      waypoints_.begin(), waypoints_.end(),
      [](const Waypoint & lhs, const Waypoint & rhs)
      {
        return lhs.time < rhs.time;
      });

    if (waypoints_.size() < 2 ||
      waypoints_.back().time <= waypoints_.front().time)
    {
      gzerr << "[WaypointObstaclePlugin] Model '" << model_->GetName()
            << "' requires increasing waypoint times.\n";
      waypoints_.clear();
      return;
    }

    trajectory_start_time_ = world_->SimTime();
    last_update_time_ = trajectory_start_time_;
    model_->SetWorldPose(waypoints_.front().pose);

    update_connection_ = event::Events::ConnectWorldUpdateBegin(
      std::bind(&WaypointObstaclePlugin::OnUpdate, this));

    gzmsg << "[WaypointObstaclePlugin] Loaded " << waypoints_.size()
          << " waypoints for '" << model_->GetName() << "'.\n";
  }

private:
  struct Waypoint
  {
    double time{0.0};
    ignition::math::Pose3d pose;
  };

  static double NormalizeAngle(const double angle)
  {
    return std::atan2(std::sin(angle), std::cos(angle));
  }

  ignition::math::Pose3d Interpolate(
    const Waypoint & from,
    const Waypoint & to,
    const double time) const
  {
    const double duration = to.time - from.time;
    const double ratio =
      duration > 1.0e-9 ?
      std::clamp((time - from.time) / duration, 0.0, 1.0) :
      0.0;

    const ignition::math::Vector3d position =
      from.pose.Pos() + ratio * (to.pose.Pos() - from.pose.Pos());
    const double yaw_from = from.pose.Rot().Yaw();
    const double yaw_delta =
      NormalizeAngle(to.pose.Rot().Yaw() - yaw_from);
    const double yaw = NormalizeAngle(yaw_from + ratio * yaw_delta);

    return ignition::math::Pose3d(
      position.X(), position.Y(), position.Z(),
      0.0, 0.0, yaw);
  }

  void OnUpdate()
  {
    if (waypoints_.size() < 2)
    {
      return;
    }

    const common::Time now = world_->SimTime();
    if (now < last_update_time_)
    {
      trajectory_start_time_ = now;
    }

    const double minimum_update_period = 1.0 / update_rate_;
    if ((now - last_update_time_).Double() < minimum_update_period)
    {
      return;
    }
    last_update_time_ = now;

    double elapsed =
      (now - trajectory_start_time_).Double() - start_delay_;
    if (elapsed <= 0.0)
    {
      model_->SetWorldPose(waypoints_.front().pose);
      return;
    }

    const double first_time = waypoints_.front().time;
    const double last_time = waypoints_.back().time;
    const double duration = last_time - first_time;

    if (loop_)
    {
      elapsed = first_time + std::fmod(elapsed, duration);
    }
    else
    {
      elapsed = std::clamp(
        first_time + elapsed, first_time, last_time);
    }

    const auto upper = std::upper_bound(
      waypoints_.begin(), waypoints_.end(), elapsed,
      [](const double value, const Waypoint & waypoint)
      {
        return value < waypoint.time;
      });

    if (upper == waypoints_.begin())
    {
      model_->SetWorldPose(waypoints_.front().pose);
      return;
    }
    if (upper == waypoints_.end())
    {
      model_->SetWorldPose(waypoints_.back().pose);
      return;
    }

    model_->SetWorldPose(
      Interpolate(*(upper - 1), *upper, elapsed));
  }

  physics::ModelPtr model_;
  physics::WorldPtr world_;
  event::ConnectionPtr update_connection_;
  std::vector<Waypoint> waypoints_;
  common::Time trajectory_start_time_;
  common::Time last_update_time_;
  bool loop_{true};
  double update_rate_{50.0};
  double start_delay_{0.0};
};

GZ_REGISTER_MODEL_PLUGIN(WaypointObstaclePlugin)

}  // namespace gazebo
